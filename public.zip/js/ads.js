var e=document.createElement('div');
e.id='adTrackerDetected';
e.style.display='none';
document.body.appendChild(e);